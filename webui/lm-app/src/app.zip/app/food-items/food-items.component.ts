import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-items',
  templateUrl: './food-items.component.html',
  styleUrls: ['./food-items.component.css']
})
export class FoodItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
