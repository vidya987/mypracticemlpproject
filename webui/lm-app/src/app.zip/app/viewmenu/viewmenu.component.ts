import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewmenu',
  templateUrl: './viewmenu.component.html',
  styleUrls: ['./viewmenu.component.css']
})
export class ViewmenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
